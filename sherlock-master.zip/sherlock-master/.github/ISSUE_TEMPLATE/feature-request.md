---
name: Feature request
about: Request a new functionality for Sherlock
title: ''
labels: enhancement
assignees: ''

---

<!--

######################################################################
  WARNING!
  IGNORING THE FOLLOWING TEMPLATE WILL RESULT IN ISSUE CLOSED AS INCOMPLETE
######################################################################

-->

## Checklist
<!--
Put x into all boxes (like this [x]) once you have completed what they say.
Make sure complete everything in the checklist.
-->
- [ ] I'm reporting a feature request
- [ ] I've checked for similar feature requests including closed ones

## Description
<!-- 
Provide a detailed description of the feature you would like Sherlock to have
-->

WRITE DESCRIPTION HERE
